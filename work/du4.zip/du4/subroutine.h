/* Header file which defines type of the subroutine subroutine_fnc */

int subroutine_fnc(char a4);
